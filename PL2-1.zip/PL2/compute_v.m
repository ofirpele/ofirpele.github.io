%[v]= compute_v(X, max_representatives_per_feature, categorical_features) 
%
% Computes for each feature its representative values and returns it in a cell vector, v.
% That is, each v{n} is a sorted vector of representative values of feature n.
%
% Required Input:
%  X - Training data, each column is a data vector.
%  max_representatives_per_feature - either a vector that sets the maximum number of representative values per
%                                    feature or a scalar which means that all dimensions have the same maximum 
%                                    number of representative values.
%                                    Note that there might be less due to empty clusters in the clustering 
%                                    method. 
%                                    Note that all max_representatives_per_feature(n) should be >= 2.
% 
% Additional input:
%  categorical_features - if categorical_features(n) is true then the representative values for this feature
%                         are the unique sets of values of the feature (unique(X(n,:)) unless there is only
%                         one and then we artificially add another value). Also, then  
%                         max_representatives_per_feature(n) is ignored.
%                         If not given all features are assumed to be non-categorical.
function [v]= compute_v(X, max_representatives_per_feature, categorical_features)

warning off stats:kmeans:EmptyCluster;
warning off stats:kmeans:FailedToConverge;

%% Inits and checks
N= size(X, 1);
M= size(X, 2);
if (length(max_representatives_per_feature)==1)
  max_representatives_per_feature= ones(N,1).*max_representatives_per_feature;
end
if (nargin==2)
  categorical_features= false(1,N);
end

for n= 1:N
  if (max_representatives_per_feature(n)<2)
	error(sprintf('max_representatives_per_feature(%d) should be >= 2',n));
  end
end

%% computing the discrete_values_vectors
v= cell(N,1);
for n= 1:N
  if (categorical_features(n))
	vn= unique(X(n,:));
  else
	vn= compute_vn_non_categorical(max_representatives_per_feature(n), X(n,:), M);
  end
  % At least 2 clusters
  if (length(vn)==1)
	vn= [vn(1) vn(1)+0.001];
  end
  v{n}= vn;
end

%% Inner function
function [vn] = compute_vn_non_categorical(max_representatives_n, X_n, M)

vn= NaN(1,max_representatives_n);
X_n_sorted= sort(X_n);
if (max_representatives_n~=2)
  num_min= sum( X_n_sorted==X_n_sorted(1) );
  num_max= sum( X_n_sorted==X_n_sorted(end) );
  % not all are minimum or maximum
  if (num_min+1<=M-num_max)
	X_n_without_max_and_min= X_n_sorted(num_min+1:M-num_max);
	[~, vn_t]= kmeans(X_n_without_max_and_min',...
		min([max_representatives_n-2 size(X_n_without_max_and_min,2)]),...
		'EmptyAction','singleton');
	vn(2:2+length(vn_t)-1)= sort(vn_t);
  end
end 
vn(1)=   X_n_sorted(1);
vn(end)= X_n_sorted(end);
% For the case where there were no enough clusters
vn(isnan(vn))= X_n_sorted(end);
vn(isinf(vn))= X_n_sorted(end); % sometimes empty clusters (no point is assigned to it) are inf
vn= unique(vn);

% Copyright (c) 2013, Ofir Pele
% All rights reserved.

% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met: 
%    * Redistributions of source code must retain the above copyright
%    notice, this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright
%    notice, this list of conditions and the following disclaimer in the
%    documentation and/or other materials provided with the distribution.
%    * The names of its contributors may not be used to endorse or promote products
%    derived from this software without specific prior written permission.

% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
