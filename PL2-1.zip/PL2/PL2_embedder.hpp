#ifndef PL2_EMBEDDER_HPP_
#define PL2_EMBEDDER_HPP_


#include "index_value_pair.hpp"
#include "OP_utils.hpp"

#include <cstdlib>
#include <vector>
#include <algorithm>

/// This class implements the embedding described in the paper:
///  The Pairwise Piecewise-Linear Embedding for Efficient Non-Linear Classification
///  Ofir Pele, Ben Taskar, Amir Globerson, Michael Werman
///  ICML 2013
/// bibTex:
///  @INPROCEEDINGS{Pele-icml2013,
///  author = {Ofir Pele and Ben Taskar and Amir Globerson and Michael Werman},
///  title = {The Pairwise Piecewise-Linear Embedding for Efficient Non-Linear Classification},
///  booktitle = {ICML},
///  year = {2013}
///  }
/// Please cite the paper if you use this code.
class PL2_embedder {
	
public:
	
	/// The constructor that initialize the embedder.
	///
	/// Params:
	///  v - Representative values of the features (in the paper we set v[n][0] to the minimum value of all
	///      feature number n values (observed in the data), v[n][D] to the maximum and the other values to
	///      the k-means centers (with k = D − 2). v[n].size() should be at least 2. See compute_v matlab code.
	///      All v[n] are required to be sorted. 
	///  feature_pairs - A pointer to a vector that contains for each feature the indices of other features
	///                  that are considered neighbors. Relationships only between neighboring features will
	///                  be modeled (thus decreasing the running time). This was done, for example, in section
	///                  5.2 in the paper.
	///                  Default: NULL which means all (v.size()*(v.size()-1))/2 feature pairs relationships
	///                  will be modeled.
	PL2_embedder(const std::vector< std::vector<double> >& v,
				 const std::vector< std::vector<size_t> >* feature_pairs_ptr=NULL);

	/// An operator() which embedds an input vector which has v.size() elements (v that was given in the
	/// constructor).  
	///
	/// Params:
	///  x_begin - an ConstInputIteratorDouble which points to the beginning of the input vector which will be
	///            embedded.
	///            *x_begin should be double or convertible to double and ++x_begin should be supported.
	///            Examples for ConstInputIteratorDouble are const double* or
	///            std::vector<double>::const_iterator. Note that the Const is just a declaration that the
	///            method does not change the doubles the iterator point to.
	///
	/// Return:
	///  The embedded vector in a sparse representation of pairs of indecies (of type size_t) and values (of
	///  type double). Note that the indices are not sorted. Note that the size of the returned vector is not
	///  the dimension of the embedded vector, but the number of non-zeros in it. The dimension of the
	///  embedded vector is returned in the embedded_vector_dimension() method.
	template<typename ConstInputIteratorDouble>
	const std::vector<index_value_pair>& operator()(ConstInputIteratorDouble x_begin) const;

	/// Return:
	///  The dimension of the embedded vector.
	size_t embedded_vector_dimension() const;

private:

	//-----------------------------------------------------------
	// fields
	//-----------------------------------------------------------
	// General for all vectors, given as input in ctor
	std::vector< std::vector<double> > _v;
	std::vector< std::vector<size_t> > _feature_pairs;

	// General for all vectors, computed once in ctor
	size_t _embedded_vector_dimension; 
	std::vector< std::vector<size_t> > _ind_1d;
	std::vector< std::vector< std::vector< std::vector<size_t> > > > _ind_2d;
	
	// For a specific input, memory is recycled between different input vectors
	mutable std::vector< double > _norm_x;
	mutable std::vector< size_t > _d_hat;
	mutable std::vector<index_value_pair> _embedded_vector; // sparse representation of the embedded vector
	mutable size_t _curr_ind_embedded_vector;
	//-----------------------------------------------------------
	
	//-----------------------------------------------------------
    void update_embedded_vector(size_t new_n, double value) const {
		mc_assert(_curr_ind_embedded_vector<_embedded_vector.size());
		mc_assert(new_n<_embedded_vector_dimension);
		_embedded_vector[_curr_ind_embedded_vector]._index= new_n;
		_embedded_vector[_curr_ind_embedded_vector]._value= value;
		++_curr_ind_embedded_vector;
    }
	//-----------------------------------------------------------

	//-----------------------------------------------------------
	void compute_embedded_vector_dimension_and_resize_embedded_vector() {
		size_t new_nz= 0;
		_embedded_vector_dimension= 0;
		for (size_t n=0; n<_v.size(); ++n) {
			_embedded_vector_dimension+= _v[n].size();
			new_nz+= 2;
			for (size_t li=0; li<_feature_pairs[n].size(); ++li) {
				size_t l= _feature_pairs[n][li];
				_embedded_vector_dimension+= _v[n].size()*_v[l].size();
				new_nz+= 3;
			}
		} // n
		_embedded_vector.resize(new_nz);
	}
	//-----------------------------------------------------------
	
	//-----------------------------------------------------------
	void fill_ind_1d() {
		size_t new_n= 0;
		_ind_1d.resize(_v.size());
		for (size_t n= 0; n<_v.size(); ++n) {
			_ind_1d[n].resize(_v[n].size());
			for (size_t d= 0; d<_v[n].size(); ++d) {
				_ind_1d[n][d]= new_n;
				++new_n;
			}
		}
		mc_assert(new_n<=_embedded_vector_dimension);
	}
	//-----------------------------------------------------------
	
	//-----------------------------------------------------------
	void fill_ind_2d() {
		_ind_2d.resize(_v.size());
		size_t new_n= _ind_1d[_v.size()-1][_v[_v.size()-1].size()-1]+1;
		for (size_t n=0; n<_v.size(); ++n) {
			_ind_2d[n].resize(_feature_pairs[n].size());
			for (size_t li=0; li<_feature_pairs[n].size(); ++li) {
				_ind_2d[n][li].resize(_v[n].size());
				size_t l= _feature_pairs[n][li];
				for (size_t d1=0; d1<_v[n].size(); ++d1) {
					_ind_2d[n][li][d1].resize(_v[l].size());
					for (size_t d2=0; d2<_v[l].size(); ++d2) {
						_ind_2d[n][li][d1][d2]= new_n;
						++new_n;
					} // d2
				} // d1
			} // li
		} // n
		
		mc_assert_eq(new_n, _embedded_vector_dimension);
	}
	//-----------------------------------------------------------
	
	//-----------------------------------------------------------
	template<typename ConstInputIteratorDouble>
	void compute_PL1(ConstInputIteratorDouble x_begin) const {
		for (size_t n=0; n<_v.size(); ++n) {

			double xnTrimmed= std::min(std::max(*x_begin, _v[n][0]), _v[n][_v[n].size()-1]);
			++x_begin;
			
			std::vector<double>::const_iterator up= std::upper_bound(_v[n].begin(), _v[n].end(), xnTrimmed); 
			_d_hat[n]= std::min(size_t(up-_v[n].begin()-1), _v[n].size()-2);

			// TODO: cache the denominator
			_norm_x[n]= (xnTrimmed-_v[n][_d_hat[n]]) / (_v[n][_d_hat[n]+1]-_v[n][_d_hat[n]]);
			
			update_embedded_vector(_ind_1d[n][_d_hat[n]],   1-_norm_x[n]);
			update_embedded_vector(_ind_1d[n][_d_hat[n]+1], _norm_x[n]);

		} // n
	} // compute_PL1
	//-----------------------------------------------------------
	
	//-----------------------------------------------------------
	template<typename ConstInputIteratorDouble>
	void compute_PL2(ConstInputIteratorDouble x_begin) const {
		_curr_ind_embedded_vector= 0;
		compute_PL1(x_begin);
		for (size_t n=0; n<_v.size(); ++n) {
			for (size_t li=0; li<_feature_pairs[n].size(); ++li) {
				size_t l= _feature_pairs[n][li];
				if (_norm_x[n]<_norm_x[l]) {
					update_embedded_vector(_ind_2d[n][li][_d_hat[n]  ][_d_hat[l]  ], 1-_norm_x[l]);
					update_embedded_vector(_ind_2d[n][li][_d_hat[n]+1][_d_hat[l]+1], _norm_x[n]);
					update_embedded_vector(_ind_2d[n][li][_d_hat[n]  ][_d_hat[l]+1], _norm_x[l]-_norm_x[n]);
				} else {
					update_embedded_vector(_ind_2d[n][li][_d_hat[n]  ][_d_hat[l]  ], 1-_norm_x[n]);
					update_embedded_vector(_ind_2d[n][li][_d_hat[n]+1][_d_hat[l]+1], _norm_x[l]);
					update_embedded_vector(_ind_2d[n][li][_d_hat[n]+1][_d_hat[l]  ], _norm_x[n]-_norm_x[l]);
				}				
			} // li
		} // n
		mc_assert(_curr_ind_embedded_vector==_embedded_vector.size());
	} // compute_PL2
	//-----------------------------------------------------------
};

//-----------------------------------------------------------
// constructor implementation
//-----------------------------------------------------------
inline PL2_embedder::PL2_embedder(const std::vector< std::vector<double> >& v,
								  const std::vector< std::vector<size_t> >* feature_pairs_ptr) :
	_v(v),
	_feature_pairs(v.size()),
	_norm_x(v.size()),
	_d_hat(v.size()) {
	
#ifndef NDEBUG
	for (size_t n=0; n<_v.size(); ++n) {
		mc_assert(_v[n].size()>=2);
		//mc_assert(std::is_sorted(v[n].begin(), v[n].end())); // works only in c++11
		for (size_t d=1; d<_v[n].size(); ++d) {
			mc_assert(_v[n][d]>_v[n][d-1]);
		}
	}
#endif
	
	if (feature_pairs_ptr==NULL) {
		for (size_t n=0; n<_v.size(); ++n) {
			_feature_pairs[n].resize(_v.size()-n-1);
			int li= 0;
			for (size_t l=n+1; l<_v.size(); ++l) {
				_feature_pairs[n][li]= l;
				++li;
			}
		}
	} else {
		_feature_pairs= *feature_pairs_ptr;
	}
	
	compute_embedded_vector_dimension_and_resize_embedded_vector();
	fill_ind_1d();
	fill_ind_2d();
} // constructor implementation
//-----------------------------------------------------------

//-----------------------------------------------------------
template<typename ConstInputIteratorDouble>
inline const std::vector<index_value_pair>& PL2_embedder::operator()(ConstInputIteratorDouble x_begin) const {
	compute_PL2(x_begin);
	return _embedded_vector;
} // operator() implementation
//-----------------------------------------------------------

//-----------------------------------------------------------
inline size_t PL2_embedder::embedded_vector_dimension() const {
	return _embedded_vector_dimension;
}
//-----------------------------------------------------------

#endif

// Copyright (c) 2013, Ofir Pele
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met: 
//    * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//    * The names of its contributors may not be used to endorse or promote products
//    derived from this software without specific prior written permission.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
