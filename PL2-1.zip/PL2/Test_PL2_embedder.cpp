#include "PL2_embedder.hpp"
#include "PL2_embedder.hpp"
#include "OP_utils.hpp"
#include <vector>
#include <iostream>
using namespace std;

//---------------------------------------------------------------------------------------------
void check_PL2_embedder(
	const vector< vector<double> >& v,
	const double* x,
	const double* should_be_embedded_x,
	size_t should_be_embedded_x_size,
	const std::vector< std::vector<size_t> >* feature_pairs_ptr=NULL) {
	
	PL2_embedder pl2tmp(v); //check that works with default params
	PL2_embedder pl2(v, feature_pairs_ptr);
	if (feature_pairs_ptr==NULL) pl2= pl2tmp;
	
	const vector<index_value_pair>& embedded_x_tmp= pl2(x);
	vector<double> embedded_x;
	OP_math_utils::convert_index_value_pair_vector_to_double_vector(
		embedded_x_tmp, pl2.embedded_vector_dimension(),
		embedded_x);
	OP_math_utils::mc_assert_range_eq(
		embedded_x.begin(), embedded_x.end(),
		should_be_embedded_x, should_be_embedded_x+should_be_embedded_x_size);

}
//---------------------------------------------------------------------------------------------

int main() {

	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.0, 20.0};
	double v0[]= {0.0, 1.0};
	double v1[]= {10.0, 30.0, 50.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	double should_be_embedded_x[]= {1.0, 0.0, 0.5, 0.5, 0.0, //1D
									0.5, 0.5, 0.0, 0.0, 0.0, 0.0};

	check_PL2_embedder(v, x, should_be_embedded_x, sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]));

	x[0]= 0.25;
	x[1]= 20.0;
	double should_be_embedded_x2[]= {0.75, 0.25, 0.5, 0.5, 0.0, //1D
									0.5, 0.25, 0.0, 0.0, 0.25, 0.0};
	check_PL2_embedder(v, x, should_be_embedded_x2, sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]));
	}
	//---------------------------------------------------------------------------------------------

	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.25, 20.0};
	double v0[]= {0.0, 1.0};
	double v1[]= {10.0, 30.0, 50.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	double should_be_embedded_x[]= {0.75, 0.25, 0.5, 0.5, 0.0, //1D
									0.5, 0.25, 0.0, 0.0, 0.25, 0.0};

	check_PL2_embedder(v, x, should_be_embedded_x, sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]));
	}
	//---------------------------------------------------------------------------------------------

	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.75, 35.0};
	double v0[]= {0.0, 1.0};
	double v1[]= {10.0, 30.0, 50.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	double should_be_embedded_x[]= {0.25, 0.75, 0, 1.0-(35.0-30.0)/(50.0-30.0), (35.0-30.0)/(50.0-30.0),
									0.0, ((35.0-30.0)/(50.0-30.0)), 0.0, 0.0,
									(1.0-((35.0-30.0)/(50.0-30.0))-(0.25)), (0.25)};
	check_PL2_embedder(v, x, should_be_embedded_x, sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]));
	}
	//---------------------------------------------------------------------------------------------


	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.3, 0.2, 16};
	double v0[]= {0.0, 1.0};
	double v1[]= {0, 1.0, 2.0};
	double v2[]= {0, 10.0, 20.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	v[2]= vector<double>(v2, v2+sizeof(v2)/sizeof(v2[0]));
	std::vector< std::vector<size_t> > feature_pairs(v.size());
	double should_be_embedded_x[]= {
		0.7,
		0.3,
		0.8,
		0.2,
		0.0 ,	 
		0.0 ,
		0.4 ,
		0.6 };
	check_PL2_embedder(v, x, should_be_embedded_x,
					   sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]),
					   &feature_pairs);
	}
	//---------------------------------------------------------------------------------------------

	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.3, 0.2, 16};
	double v0[]= {0.0, 1.0};
	double v1[]= {0, 1.0, 2.0};
	double v2[]= {0, 10.0, 20.0, 30.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	v[2]= vector<double>(v2, v2+sizeof(v2)/sizeof(v2[0]));
	std::vector< std::vector<size_t> > feature_pairs(v.size());
	feature_pairs[0].push_back(2);
	double should_be_embedded_x[]= {
	 0.7,
	 0.3,

	 0.8,
	 0.2,
	 0.0 ,

	 0.0 ,
	 0.4 ,
	 0.6 , 
	 0.0 , //1D

	 0.0 , //1
	 0.4 , //2
	 0.3 , //3
	 0.0 , //4
	 0.0 , //5
	 0.0 , //6
	 0.3 , //7
	 0.0}; //8
	check_PL2_embedder(v, x, should_be_embedded_x,
					   sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]),
					   &feature_pairs);
	}
	//---------------------------------------------------------------------------------------------

	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.3, 0.2, 16};
	double v0[]= {0.0, 1.0};
	double v1[]= {0, 1.0, 2.0};
	double v2[]= {0, 10.0, 20.0, 30.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	v[2]= vector<double>(v2, v2+sizeof(v2)/sizeof(v2[0]));
	std::vector< std::vector<size_t> > feature_pairs(v.size());
	feature_pairs[0].push_back(1);
	double should_be_embedded_x[]= {
 	 0.7,
 	 0.3,
 	 0.8,
 	 0.2,
 	 0.0 ,
	 
 	 0.0 ,
 	 0.4 ,
 	 0.6 , 
 	 0.0 , //1D
 	
 	 0.7 , //1
 	 0.0 , //2
 	 0.0 , //3
 	 0.1 , //4
 	 0.2 , //5
 	 0.0  //6
	};
	check_PL2_embedder(v, x, should_be_embedded_x,
					   sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]),
					   &feature_pairs);
	}
	//---------------------------------------------------------------------------------------------
	
	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.3, 0.2, 16};
	double v0[]= {0.0, 1.0};
	double v1[]= {0, 1.0, 2.0};
	double v2[]= {0, 10.0, 20.0, 30.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	v[2]= vector<double>(v2, v2+sizeof(v2)/sizeof(v2[0]));
	std::vector< std::vector<size_t> > feature_pairs(v.size());
	feature_pairs[0].push_back(1);
	feature_pairs[1].push_back(2);
	double should_be_embedded_x[]= {
		0.7,
		0.3,
		
		0.8,
		0.2,
		0.0 ,
		
		0.0 ,
		0.4 ,
		0.6 , 
		0 , //1D
		
		0.7 , //1
		0.0 , //2
		0.0 , //3
		0.1 , //4
		0.2 , //5
		0.0 , //6
		
		0.0 , //1
		0.4 , //2
		0.4 , //3
		0.0 , //4
		0.0 , //5
		0.0 , //6
		0.2 , //7
		0.0 , //8
		0.0 , //9
		0.0 , //10
		0.0 , //11
		0.0  //12
	};
	check_PL2_embedder(v, x, should_be_embedded_x,
					   sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]),
					   &feature_pairs);
	}
	//---------------------------------------------------------------------------------------------

	//---------------------------------------------------------------------------------------------
	{
	double x[]= {0.3, 0.2, 16};
	double v0[]= {0.0, 1.0};
	double v1[]= {0, 1.0, 2.0};
	double v2[]= {0, 10.0, 20.0, 30.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	v[2]= vector<double>(v2, v2+sizeof(v2)/sizeof(v2[0]));
	std::vector< std::vector<size_t> > feature_pairs(v.size());
	feature_pairs[0].push_back(1);
	feature_pairs[0].push_back(2);
	feature_pairs[1].push_back(2);
	double should_be_embedded_x[]= {
			0.7,
	0.3,
		
	 0.8,
	 0.2,
	 0.0,
	  
	 0.0,
	 0.4 ,
	 0.6 , 
	 0.0  //1D
	  , 
	 0.7 , //1 
	 0.0, //2
	 0.0, //3
	 0.1 , //4
	 0.2 , //5
	 0.0, //6      //1-2
	  
	 0.0, //1
	 0.4 , //2
	 0.3 , //3
	 0.0, //4
	 0.0, //5
	 0.0, //6
	 0.3 , //7
	 0.0, //8          //2-3
	  
	 0.0, //1
	 0.4 , //2
	 0.4 , //3
	 0.0, //4
	 0.0, //5
	 0.0, //6
	0.2 , //7
	 0.0, //8
	 0.0, //9
	 0.0, //10
	 0.0, //11
	 0.0 //12   //2-3
	};
	check_PL2_embedder(v, x, should_be_embedded_x,
					   sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]),
					   &feature_pairs);
	}
	//---------------------------------------------------------------------------------------------


	//---------------------------------------------------------------------------------------------
	{
	// same as previous only with default of all neighbors 
	double x[]= {0.3, 0.2, 16};
	double v0[]= {0.0, 1.0};
	double v1[]= {0, 1.0, 2.0};
	double v2[]= {0, 10.0, 20.0, 30.0};
	vector< vector<double> > v(sizeof(x)/sizeof(x[0]));
	v[0]= vector<double>(v0, v0+sizeof(v0)/sizeof(v0[0]));
	v[1]= vector<double>(v1, v1+sizeof(v1)/sizeof(v1[0]));
	v[2]= vector<double>(v2, v2+sizeof(v2)/sizeof(v2[0]));
	double should_be_embedded_x[]= {
			0.7,
	0.3,
		
	 0.8,
	 0.2,
	 0.0,
	  
	 0.0,
	 0.4 ,
	 0.6 , 
	 0.0  //1D
	  , 
	 0.7 , //1 
	 0.0, //2
	 0.0, //3
	 0.1 , //4
	 0.2 , //5
	 0.0, //6      //1-2
	  
	 0.0, //1
	 0.4 , //2
	 0.3 , //3
	 0.0, //4
	 0.0, //5
	 0.0, //6
	 0.3 , //7
	 0.0, //8          //2-3
	  
	 0.0, //1
	 0.4 , //2
	 0.4 , //3
	 0.0, //4
	 0.0, //5
	 0.0, //6
	0.2 , //7
	 0.0, //8
	 0.0, //9
	 0.0, //10
	 0.0, //11
	 0.0 //12   //2-3
	};
	check_PL2_embedder(v, x, should_be_embedded_x,
					   sizeof(should_be_embedded_x)/sizeof(should_be_embedded_x[0]));
	}
	//---------------------------------------------------------------------------------------------

	cout << "All tests passed OK :)" << endl;
	
	return 0;

}

// Copyright (c) 2013, Ofir Pele
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met: 
//    * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//    * The names of its contributors may not be used to endorse or promote products
//    derived from this software without specific prior written permission.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
