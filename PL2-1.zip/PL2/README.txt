Code for the pairwise piecewise-linear embedding
------------------------------------------------
Ofir Pele 
Contact: ofirpele@gmail.com
Version: 1, July 2013

This directory contains the source code for computing the pairwise piecewise-linear embedding.

Please cite this paper if you use this code:
 The Pairwise Piecewise-Linear Embedding for Efficient Non-Linear Classification
 Ofir Pele, Ben Taskar, Amir Globerson, Michael Werman
 ICML 2013
bibTex:
@INPROCEEDINGS{Pele-icml2013,
 author = {Ofir Pele and Ben Taskar and Amir Globerson and Michael Werman},
 title = {The Pairwise Piecewise-Linear Embedding for Efficient Non-Linear Classification},
 booktitle = {ICML},
 year = {2013}
}

I plan to publish a new distribution that will include SVM learning with a stochastic subgradient decent 
algorithm with embedding on the fly in the future. I also hope to publish a version that uses the GPU.

Easy startup
------------
File PL2_embedder contains the class that can embed input vectors. You need to first use the constructor and
then use the operator() to embed input vectors. compute_v is a matlab utility that computes for each feature 
its representative values.

Compiling (the folder contains compiled binaries, thus you might not have to compile)
-------------------------------------------------------------------------------------
In a linux shell:
>> make

Licensing conditions
--------------------
See the file LICENSE.txt in this directory for conditions of use.
