#ifndef OP_UTILS_HPP_
#define OP_UTILS_HPP_

#include <iostream>
#include <math.h>
#include <map>
#include <string>
#include <sstream>
#include <vector>
#include "index_value_pair.hpp"

//====================================================
// Assert
//====================================================
#ifdef MATLAB_MEX_FILE
#include <mex.h>
#else
#include <cassert>
#endif

// Note: In MATLAB_MEX_FILE mxAssert is active ONLY when -g is active
// Note: assert is active ONLY if NDEBUG is not defined

#ifdef MATLAB_MEX_FILE
#define mc_assert(expr) mxAssert((expr),"")
//#define mc_assert(expr) {mxAssert((expr),""); std::string mc_assert_str= "mc_assert failed on line: "; std::stringstream mc_assert_st; mc_assert_st << __LINE__; mc_assert_str+=mc_assert_st.str(); mc_assert_str+= " file: "; mc_assert_str+=std::string(__FILE__); if (!(expr)) mexErrMsgTxt(mc_assert_str.c_str());}
#else
#define mc_assert(expr) assert((expr))
#endif


#define ASSERT_EQUAL_EPSILON 0.001

#ifdef MATLAB_MEX_FILE
#define mc_assert_eq(a,b) mxAssert((fabs((a)-(b)))<ASSERT_EQUAL_EPSILON,"")
//#define mc_assert_eq(a,b) {mxAssert((fabs((a)-(b)))<ASSERT_EQUAL_EPSILON,""); if (!((fabs((a)-(b)))<ASSERT_EQUAL_EPSILON,"")) mexErrMsgTxt("mc_assert_eq failed");} 
#else
#define mc_assert_eq(a,b) assert((fabs((a)-(b)))<ASSERT_EQUAL_EPSILON)
#endif

#ifdef MATLAB_MEX_FILE
#define mc_assert_geq(a,b) mxAssert((a)>=((b)-ASSERT_EQUAL_EPSILON),"")
//#define mc_assert_geq(a,b) {mxAssert((a)>=((b)-ASSERT_EQUAL_EPSILON),""); if (!((a)>=((b)-ASSERT_EQUAL_EPSILON),"")) mexErrMsgTxt("mc_assert_geq failed");}
#else
#define mc_assert_geq(a,b) assert((a)>=((b)-ASSERT_EQUAL_EPSILON))
#endif


//====================================================

//====================================================
class OP_math_utils {
public:

	//-----------------------------------------------------------------
	template<typename ConstInputIteratorDouble1, typename ConstInputIteratorDouble2>
	static void mc_assert_range_eq(ConstInputIteratorDouble1 begin1, ConstInputIteratorDouble1 end1,
								   ConstInputIteratorDouble2 begin2, ConstInputIteratorDouble2 end2) {

		//std::cout << "-------------------------------" << std::endl;
		while ( (begin1!=end1) && (begin2!=end2) ) {
			//std::cout << *begin1 << " " << *begin2 << std::endl;
			mc_assert_eq(*begin1,*begin2);
			++begin1;
			++begin2;
		}
		mc_assert( (begin1==end1) && (begin2==end2) );
		
	} // mc_assert_range_eq
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	static void convert_index_value_pair_vector_to_double_vector(const std::vector<index_value_pair>& in,
																 size_t out_size,
																 std::vector<double>& out) {
		out= std::vector<double>(out_size, 0.0);
		for (size_t n=0; n<in.size(); ++n) {
			out[ in[n]._index ]= in[n]._value;
		}
	} // convert_index_value_pair_vector_to_double_vector
	//-----------------------------------------------------------------
	
	//-----------------------------------------------------------------
	template<typename index_T>
	static double maps_dot_product(const std::map< index_T,double >& m1,
							const std::map< index_T,double >& m2) {

		typedef typename std::map< index_T,double >::const_iterator it_T;

		double res= 0;
		it_T m1_it= m1.begin();
		it_T m2_it= m2.begin();

		// mexPrintf("==========================\n");
		// while (m1_it!=m1.end()) {
		// 	mexPrintf("(%d %f) ", m1_it->first, m1_it->second);
		// 	++m1_it;
		// }
		// mexPrintf("\n");
		// while (m2_it!=m2.end()) {
		// 	mexPrintf("(%d %f) ", m2_it->first, m2_it->second);
		// 	++m2_it;
		// }
		// mexPrintf("\n");
		// m1_it= m1.begin();
		// m2_it= m2.begin();
		// mexPrintf("==========================\n");
		
		
		while (m1_it!=m1.end()&&m2_it!=m2.end()) {

			while (m1_it->first < m2_it->first) {
				++m1_it;
				if (m1_it==m1.end()) return res;
			}

			while (m2_it->first < m1_it->first) {
				++m2_it;
				if (m2_it==m2.end()) return res;
			}

			if (m1_it->first==m2_it->first) {
				res+= (m1_it->second*m2_it->second);
				++m1_it;
				++m2_it;
			}

		}

		return res;
	} // maps_dot_product
	//-----------------------------------------------------------------

		
};
//====================================================
#endif

// Copyright (c) 2013, Ofir Pele
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met: 
//    * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//    * The names of its contributors may not be used to endorse or promote products
//    derived from this software without specific prior written permission.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

