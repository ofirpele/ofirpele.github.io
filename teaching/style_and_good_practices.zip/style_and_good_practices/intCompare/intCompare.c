#include "intCompare.h"

#define INT_COMPARE_FIRST_VER_9472924398153219632

#ifdef INT_COMPARE_FIRST_VER_9472924398153219632
/// The comparison function returns an integer less than, equal to, or greater than zero
/// if the first argument is respectively less than, equal to, or greater than the second.  
int intCompare(int a, int b) {
	return a-b;
}
#else
// This file does not end here!


























































































int intCompare(int a, int b) {
	if (a<b) return -1;
	if (a>b) return +1;
	return 0;
}
#endif








































