#include "intCompare.h"
#include <stdio.h>

int main() {
	printf("Should be >0 %d\n",intCompare(5,4));
	printf("Should be <0 %d\n",intCompare(4,5));
	printf("Should be ==0 %d\n",intCompare(5,5));

	return 0;
}
