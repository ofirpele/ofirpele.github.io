#pragma once

/// The comparison function returns an integer less than, equal to, or greater than zero
/// if the first argument is respectively less than, equal to, or greater than the second.  
int intCompare(int a, int b);
