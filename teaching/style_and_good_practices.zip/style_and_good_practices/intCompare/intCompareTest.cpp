extern "C" {
#include "intCompare.h"
}
#include "gtest/gtest.h"
#include <limits.h>

TEST(intCompare, similarToOldAndUglyTestNowNotUgly) {
	//----------gtest-------------- ====catch=======================
	EXPECT_GT(intCompare(5,4), 0); // REQUIRE( intCompare(5,4) > 0)
	EXPECT_LT(intCompare(4,5), 0); // REQUIRE( intCompare(4,5) < 0)
	EXPECT_EQ(intCompare(5,5), 0); // REQUIRE( intCompare(4,5) == 0)
}

TEST(intCompare, negNums) {
	EXPECT_GT(intCompare(5,-4), 0);
	EXPECT_LT(intCompare(-4,5), 0);
	EXPECT_EQ(intCompare(-5,-5), 0);

	EXPECT_GT(intCompare(-4,-5), 0);
	EXPECT_LT(intCompare(-5,-4), 0);
	// ...
}

TEST(intCompare, bigSmallTest) {
	for (int i=-100; i<100; ++i) {
		EXPECT_GT(intCompare(INT_MAX, i), 0);
		EXPECT_LT(intCompare(INT_MIN, i), 0);
	}

	EXPECT_GT(intCompare(INT_MAX, INT_MIN), 0);
	EXPECT_LT(intCompare(INT_MIN, INT_MAX), 0);

	EXPECT_EQ(intCompare(INT_MAX, INT_MAX), 0);
	EXPECT_EQ(intCompare(INT_MIN, INT_MIN), 0);
}

