This is a simple int comparator function with two types of testing:
- oldAndUglyTest: printf style
- Test: Google's Unit Testing framework

To install it:
1. Run 'make installonce' in the shell to install Google test framework 
and makedepend. This should be done only once.
2. Run 'make' in the shell to install the int compare testing and 
then run the tests.
3. If you change the name of files / includes you'll possibly need to 
update the Makefile and then run 'make depend' and only then run 'make'. 
If you change just the code in one of the files you'll only need to run 'make'.

You can also run the test executable, e.g., myabsdiffTest with the --help param. That is:
$ intCompare --help

