mex -O -largeArrayDims -DNDEBUG QC_full_sparse.cxx
mex -O -largeArrayDims -DNDEBUG fast_sift_bin_similarity_matrix.cxx
mex -O -largeArrayDims -DNDEBUG fast_color_spatial_ground_similarity_pruning.cxx
mex -O -largeArrayDims -DNDEBUG check_if_QC_valid_bin_similarity_matrix.cxx

